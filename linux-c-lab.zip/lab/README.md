# Linux, Shell, and C Lab

## Overview
This repository contains my work for the Ubuntu Linux command line, shell scripting, and C programming lab (CS375 Lab 1), completed in GitHub Codespaces.

## Structure
- `command-line/`: Logs from command-line tasks (`easy-log.txt`, `intermediate-log.txt`, `advanced-log.txt`) and the scripts that generate them (`make-logs.sh`, `advanced-log.sh`).
- `shell-scripts/`: Shell scripts for automation (`easy-greet.sh`, `file-check.sh`, `file-count.sh`, `project.sh`).
- `c-programs/`: C programs with compilation (`easy-c.c`, `add.c`, `intermediate-c.c`, `factorial.c`, `advanced-c.c`, `contacts.c`).

## Testing and Running
- **Command Line:** Used `ls`, `cd`, `cp`, `mv`, `chmod`, `grep`, `find`, `ps` and more in Codespaces. `make-logs.sh` records each command and its output in `easy-log.txt` and `intermediate-log.txt`; `advanced-log.sh` automates a directory listing (`ls -l`, `tree`, `PATH`) into `advanced-log.txt`.
- **Shell Scripts:** Tested `easy-greet.sh` with a typed name (prints a greeting and the date), `file-check.sh` with an existing and a missing file, `file-count.sh` against `c-programs/` and an invalid directory.
- **C Programs:** Compiled every program with `gcc -Wall -Wextra`. `add.c` with 3 and 4 gives 7; `factorial.c` with 5 gives 120; `contacts.c` (built with `gcc -g`) adds and lists contacts saved in `contacts.txt`.
- **Project:** `project.sh` compiles and runs `contacts.c`, backs up the C sources to `contacts-backup.tar.gz`, and logs the run time to `project-log.txt`.

### How to run
```bash
# Command line logs
cd command-line && chmod +x *.sh && ./make-logs.sh && ./advanced-log.sh && cd ..

# Shell scripts
cd shell-scripts && chmod +x *.sh
./easy-greet.sh
./file-check.sh easy-greet.sh
./file-count.sh ../c-programs
./project.sh
cd ..

# C programs
cd c-programs
gcc add.c -o add && ./add
gcc factorial.c -o factorial && ./factorial
gcc -g contacts.c -o contacts && ./contacts
```

## Challenges and Learnings
- Learned Git commits, branches and pull requests, and debugging C with `gdb`.
- Challenges: file permissions (`Permission denied` until `chmod +x`), pointer syntax, and mixing `scanf` with `fgets` (leftover newlines in the input buffer).
